package com.nexlink.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.media.MediaRecorder
import java.io.File
import androidx.core.content.FileProvider
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

private val Navy = Color(0xFF071A35)
private val Blue = Color(0xFF123D70)
private val Teal = Color(0xFF19D3C5)
private val Canvas = Color(0xFFF4F7FB)
private const val PREFS = "nexlink_store"
private const val STORE_KEY = "data_v1"
private const val CHANNEL_ID = "nexlink_reminders"

private data class VirtualGroup(val id: String, val name: String, val description: String = "")
private data class Draft(val id: String, val title: String, val body: String, val workspace: String, val group: String, val attachment: String = "", val created: Long = System.currentTimeMillis(), val status: String = "Préparé", val scheduleDate: String = "", val scheduleTime: String = "")
private data class Reminder(val id: String, val title: String, val date: String, val time: String, val note: String = "", val done: Boolean = false)
private data class PubProfile(val id: String, val name: String, val workspace: String, val description: String = "")

private class NexlinkStore(context: Context) {
    private val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    init { if (!read().has("groups")) { saveGroup(VirtualGroup("seed-rbp", "Record Breaking Prayers", "RBP announcements and prayer content")); saveGroup(VirtualGroup("seed-btc", "Breaking The Chains", "Friday fasting and prayer content")); saveGroup(VirtualGroup("seed-lgb", "Les Grandes Bouches", "Football discussion content")) } }
    private fun read(): JSONObject = try { JSONObject(prefs.getString(STORE_KEY, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
    private fun write(o: JSONObject) { prefs.edit().putString(STORE_KEY, o.toString()).apply() }
    private fun readArray(key: String): JSONArray = read().optJSONArray(key) ?: JSONArray()
    private fun saveArray(key: String, array: JSONArray) { val root = read(); root.put(key, array); write(root) }
    fun getSetting(key: String, fallback: String) = read().optString("setting_$key", fallback)
    fun setSetting(key: String, value: String) { val o = read(); o.put("setting_$key", value); write(o) }
    fun exportJson(): String = read().toString(2)
    fun importJson(json: String) { val parsed = JSONObject(json); write(parsed) }
    fun groups(): List<VirtualGroup> { val a = readArray("groups"); return (0 until a.length()).map { val o=a.getJSONObject(it); VirtualGroup(o.optString("id"),o.optString("name"),o.optString("description")) } }
    fun saveGroup(g: VirtualGroup) { val list=groups().filterNot { it.id==g.id } + g; val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("description",it.description)) }; saveArray("groups",a) }
    fun deleteGroup(id: String) { val a=JSONArray(); groups().filterNot { it.id==id }.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("description",it.description)) }; saveArray("groups",a) }
    fun drafts(): List<Draft> { val a=readArray("drafts"); return (0 until a.length()).map { val o=a.getJSONObject(it); Draft(o.optString("id"),o.optString("title"),o.optString("body"),o.optString("workspace"),o.optString("group"),o.optString("attachment"),o.optLong("created"),o.optString("status","Préparé"),o.optString("scheduleDate"),o.optString("scheduleTime")) }.sortedByDescending { it.created } }
    fun saveDraft(d: Draft) { val list=drafts().filterNot { it.id==d.id } + d; val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("title",it.title).put("body",it.body).put("workspace",it.workspace).put("group",it.group).put("attachment",it.attachment).put("created",it.created).put("status",it.status).put("scheduleDate",it.scheduleDate).put("scheduleTime",it.scheduleTime)) }; saveArray("drafts",a) }
    fun deleteDraft(id: String) { val a=JSONArray(); drafts().filterNot { it.id==id }.forEach { a.put(JSONObject().put("id",it.id).put("title",it.title).put("body",it.body).put("workspace",it.workspace).put("group",it.group).put("attachment",it.attachment).put("created",it.created).put("status",it.status).put("scheduleDate",it.scheduleDate).put("scheduleTime",it.scheduleTime)) }; saveArray("drafts",a) }
    fun reminders(): List<Reminder> { val a=readArray("reminders"); return (0 until a.length()).map { val o=a.getJSONObject(it); Reminder(o.optString("id"),o.optString("title"),o.optString("date"),o.optString("time"),o.optString("note"),o.optBoolean("done")) }.sortedBy { it.date+it.time } }
    fun saveReminder(r: Reminder) { val list=reminders().filterNot { it.id==r.id } + r; val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("title",it.title).put("date",it.date).put("time",it.time).put("note",it.note).put("done",it.done)) }; saveArray("reminders",a) }
    fun deleteReminder(id: String) { val a=JSONArray(); reminders().filterNot { it.id==id }.forEach { a.put(JSONObject().put("id",it.id).put("title",it.title).put("date",it.date).put("time",it.time).put("note",it.note).put("done",it.done)) }; saveArray("reminders",a) }
    fun profiles(): List<PubProfile> { val a=readArray("profiles"); return (0 until a.length()).map { val o=a.getJSONObject(it); PubProfile(o.optString("id"),o.optString("name"),o.optString("workspace"),o.optString("description")) } }
    fun saveProfile(p: PubProfile) { val list=profiles().filterNot { it.id==p.id } + p; val a=JSONArray(); list.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("workspace",it.workspace).put("description",it.description)) }; saveArray("profiles",a) }
    fun deleteProfile(id: String) { val a=JSONArray(); profiles().filterNot { it.id==id }.forEach { a.put(JSONObject().put("id",it.id).put("name",it.name).put("workspace",it.workspace).put("description",it.description)) }; saveArray("profiles",a) }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); createChannel(); setContent { NexlinkApp(NexlinkStore(this)) } }
    private fun createChannel() { if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) { val nm=getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager; nm.createNotificationChannel(NotificationChannel(CHANNEL_ID,"Nexlink reminders",NotificationManager.IMPORTANCE_HIGH).apply { description="Local reminders created in Nexlink" }) } }
}

@Composable
private fun NexlinkApp(store: NexlinkStore) {
    val context = LocalContext.current
    var refresh by remember { mutableIntStateOf(0) }
    var tab by remember { mutableStateOf("Accueil") }
    var language by remember { mutableStateOf(store.getSetting("language","FR")) }
    var workspace by remember { mutableStateOf(store.getSetting("workspace","Messenger")) }
    var dark by remember { mutableStateOf(store.getSetting("theme","light")=="dark") }
    var search by remember { mutableStateOf("") }
    var showGroup by remember { mutableStateOf(false) }
    var editingGroup by remember { mutableStateOf<VirtualGroup?>(null) }
    var showDraft by remember { mutableStateOf(false) }
    var editingDraft by remember { mutableStateOf<Draft?>(null) }
    var showReminder by remember { mutableStateOf(false) }
    var showProfile by remember { mutableStateOf(false) }
    var attachment by remember { mutableStateOf("") }
    var toast by remember { mutableStateOf("") }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var recordingFile by remember { mutableStateOf<File?>(null) }
    val french = language == "FR"
    val groups = remember(refresh) { store.groups() }
    val drafts = remember(refresh) { store.drafts() }
    val reminders = remember(refresh) { store.reminders() }
    val profiles = remember(refresh) { store.profiles() }
    val pickFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> if(uri!=null) { try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}; attachment=uri.toString(); toast=if(french) "Fichier ajouté au brouillon" else "File attached" } }
    val exportFile = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? -> if(uri!=null) try { context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(store.exportJson()) }; toast=if(french) "Sauvegarde exportée" else "Backup exported" } catch(e:Exception) { toast="Export failed: ${e.message}" } }
    val importFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? -> if(uri!=null) try { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { store.importJson(it.readText()) }; store.reminders().filterNot{it.done}.forEach{scheduleReminder(context,it)}; refresh++; toast=if(french) "Sauvegarde restaurée" else "Backup restored" } catch(e:Exception) { toast=if(french) "Fichier de sauvegarde invalide" else "Invalid backup file" } }
    val beginRecording: () -> Unit = { try { val f=File(context.cacheDir,"nexlink-audio-${System.currentTimeMillis()}.m4a"); val mr=if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.S) MediaRecorder(context) else MediaRecorder(); mr.setAudioSource(MediaRecorder.AudioSource.MIC); mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); mr.setOutputFile(f.absolutePath); mr.prepare(); mr.start(); recorder=mr; recordingFile=f; recording=true; toast=if(french) "Enregistrement en cours…" else "Recording started…" } catch(e:Exception) { recorder?.release(); recorder=null; recording=false; toast=if(french) "Impossible de démarrer le microphone : autorisez son accès." else "Could not start microphone; allow microphone access." } }
    val requestAudio = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if(granted) beginRecording() else toast=if(french) "Autorisez le microphone pour enregistrer." else "Allow microphone access to record." }
    val stopRecording: () -> Unit = { try { recorder?.stop(); recorder?.release(); recorder=null; val f=recordingFile; if(f!=null) attachment=FileProvider.getUriForFile(context,"com.nexlink.app.fileprovider",f).toString(); toast=if(french) "Audio enregistré et joint au brouillon." else "Audio recorded and attached to draft." } catch(e:Exception) { toast=if(french) "L'enregistrement n'a pas pu être finalisé." else "Recording could not be finalized."; recorder?.release(); recorder=null } finally { recording=false } }
    val requestNotifications = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    MaterialTheme(colorScheme = if(dark) darkColorScheme(primary=Teal,secondary=Teal,background=Navy,surface=Color(0xFF102642)) else lightColorScheme(primary=Blue,secondary=Teal,background=Canvas,surface=Color.White)) {
        val bg = if(dark) Color(0xFF061426) else Canvas
        Scaffold(containerColor=bg, bottomBar={ NavigationBar(containerColor=if(dark) Color(0xFF0C2039) else Color.White) { val tabs=listOf("Accueil","Groupes","Calendrier","Bibliothèque","Réglages"); val icons=listOf(Icons.Default.Home,Icons.Default.Groups,Icons.Default.CalendarMonth,Icons.Default.Folder,Icons.Default.Settings); tabs.forEachIndexed { i,label -> NavigationBarItem(selected=tab==label,onClick={tab=label},icon={Icon(icons[i],null)},label={Text(if(french) label else listOf("Home","Groups","Calendar","Library","Settings")[i],fontSize=9.sp)},colors=NavigationBarItemDefaults.colors(selectedIconColor=Blue,indicatorColor=Teal.copy(alpha=.25f))) } } }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                Header(workspace,{ workspace=it; store.setSetting("workspace",it) },language,{ language=it; store.setSetting("language",it) },dark)
                if(tab=="Bibliothèque" || tab=="Groupes") OutlinedTextField(value=search,onValueChange={search=it},modifier=Modifier.fillMaxWidth().padding(horizontal=16.dp, vertical=8.dp),placeholder={Text(if(french) "Rechercher dans Nexlink…" else "Search Nexlink…")},leadingIcon={Icon(Icons.Default.Search,null)},singleLine=true,shape=RoundedCornerShape(14.dp))
                when(tab) {
                    "Accueil" -> HomeScreen(french,groups.size,drafts.size,reminders.count{!it.done},{tab="Groupes"},{showDraft=true;editingDraft=null;attachment=""},{tab="Calendrier"},{tab="Bibliothèque"})
                    "Groupes" -> GroupsScreen(french,groups.filter{it.name.contains(search,true)||it.description.contains(search,true)}, {showGroup=true;editingGroup=null}, { editingGroup=it; showGroup=true }, { id -> store.deleteGroup(id); refresh++ })
                    "Calendrier" -> CalendarScreen(french,reminders,drafts.filter{it.scheduleDate.isNotBlank()&&it.scheduleTime.isNotBlank()},{showReminder=true},{ r -> store.saveReminder(r.copy(done=!r.done)); if(!r.done) WorkManager.getInstance(context).cancelUniqueWork("reminder_${r.id}"); refresh++ },{ id -> store.deleteReminder(id); WorkManager.getInstance(context).cancelUniqueWork("reminder_$id"); refresh++ })
                    "Bibliothèque" -> LibraryScreen(french,drafts.filter{it.title.contains(search,true)||it.body.contains(search,true)||it.group.contains(search,true)}, {showDraft=true;editingDraft=null;attachment=""}, { d -> editingDraft=d; attachment=d.attachment; showDraft=true }, { d -> shareDraft(context,d); store.saveDraft(d.copy(status="Partage lancé (non confirmé)")); refresh++ }, { d -> store.deleteDraft(d.id); store.deleteReminder("draft-${d.id}"); WorkManager.getInstance(context).cancelUniqueWork("reminder_draft-${d.id}"); refresh++ }, {pickFile.launch(arrayOf("image/*","video/*","audio/*","application/pdf"))})
                    else -> SettingsScreen(french,workspace,{ workspace=it; store.setSetting("workspace",it) },language,{language=it;store.setSetting("language",it)},dark,{dark=it;store.setSetting("theme",if(it)"dark" else "light")},profiles,{showProfile=true},{p->store.deleteProfile(p.id);refresh++},{exportFile.launch("nexlink-backup.json")},{importFile.launch(arrayOf("application/json","text/*"))},{if(Build.VERSION.SDK_INT>=33) requestNotifications.launch(Manifest.permission.POST_NOTIFICATIONS) else toast=if(french) "Les notifications sont gérées par Android" else "Notifications are managed by Android"})
                }
            }
        }
        if(showGroup) GroupDialog(french,editingGroup,{showGroup=false},{name,desc-> val g=VirtualGroup(editingGroup?.id ?: java.util.UUID.randomUUID().toString(),name,desc);store.saveGroup(g);refresh++;showGroup=false })
        if(showDraft) DraftDialog(french,editingDraft,workspace,groups,attachment,{pickFile.launch(arrayOf("image/*","video/*","audio/*","application/pdf"))},{if(recording) stopRecording() else requestAudio.launch(Manifest.permission.RECORD_AUDIO)},recording,{showDraft=false},{d->store.saveDraft(d);if(d.scheduleDate.isNotBlank()&&d.scheduleTime.isNotBlank()&&validDateTime(d.scheduleDate,d.scheduleTime)){val rr=Reminder("draft-${d.id}",d.title.ifBlank{if(french)"Publication Nexlink" else "Nexlink post"},d.scheduleDate,d.scheduleTime,d.body);store.saveReminder(rr);scheduleReminder(context,rr)};refresh++;showDraft=false;toast=if(french)"Brouillon enregistré sur cet appareil" else "Draft saved on this device"})
        if(showReminder) ReminderDialog(french,{showReminder=false},{r->store.saveReminder(r);scheduleReminder(context,r);refresh++;showReminder=false;toast=if(french)"Rappel programmé" else "Reminder scheduled"})
        if(showProfile) ProfileDialog(french,{showProfile=false},{name,desc->store.saveProfile(PubProfile(java.util.UUID.randomUUID().toString(),name,workspace,desc));refresh++;showProfile=false})
        if(toast.isNotBlank()) AlertDialog(onDismissRequest={toast=""},title={Text(if(french)"Nexlink" else "Nexlink")},text={Text(toast)},confirmButton={TextButton(onClick={toast=""}){Text("OK")}})
    }
}

@Composable private fun Header(workspace:String,setWorkspace:(String)->Unit,language:String,setLanguage:(String)->Unit,dark:Boolean) {
    Row(Modifier.fillMaxWidth().background(Navy).padding(horizontal=16.dp,vertical=13.dp),verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.size(42.dp).background(Teal,RoundedCornerShape(13.dp)),contentAlignment=Alignment.Center){Text("N",color=Navy,fontWeight=FontWeight.Black,fontSize=25.sp)}
        Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f)){Text("NEXLINK",color=Color.White,fontWeight=FontWeight.ExtraBold,letterSpacing=2.sp,fontSize=18.sp);Text("Connect. Prepare. Share.",color=Teal,fontSize=10.sp)}
        Text(language,color=Color.White,modifier=Modifier.clickable{setLanguage(if(language=="FR")"EN" else "FR")}.padding(8.dp),fontWeight=FontWeight.Bold)
        Column(horizontalAlignment=Alignment.CenterHorizontally){Text(if(workspace=="Business")"Business" else "Messenger",color=Color.White,fontSize=10.sp);Switch(checked=workspace=="Business",onCheckedChange={setWorkspace(if(it)"Business" else "Messenger")},modifier=Modifier.height(24.dp),colors=SwitchDefaults.colors(checkedThumbColor=Teal,checkedTrackColor=Blue))}
    }
}

@Composable private fun HomeScreen(fr:Boolean,groupCount:Int,draftCount:Int,reminderCount:Int,groups:()->Unit,compose:()->Unit,calendar:()->Unit,library:()->Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(13.dp)) {
        item{Text(if(fr)"Votre espace de travail" else "Your workspace",fontSize=26.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground);Text(if(fr)"Préparez. Organisez. Partagez." else "Prepare. Organize. Share.",color=Color.Gray)}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard(if(fr)"Groupes" else "Groups",groupCount.toString(),Icons.Default.Groups,Modifier.weight(1f));StatCard(if(fr)"Brouillons" else "Drafts",draftCount.toString(),Icons.Default.EditNote,Modifier.weight(1f));StatCard(if(fr)"Rappels" else "Reminders",reminderCount.toString(),Icons.Default.NotificationsActive,Modifier.weight(1f))}}
        item{Text(if(fr)"Actions rapides" else "Quick actions",fontWeight=FontWeight.Bold,fontSize=18.sp,color=MaterialTheme.colorScheme.onBackground)}
        item{ActionCard("✎",if(fr)"Préparer un message" else "Prepare a message",if(fr)"Enregistrer un brouillon et joindre un média" else "Save a draft and attach media",compose)}
        item{ActionCard("▦",if(fr)"Organiser les groupes" else "Organize groups",if(fr)"Créer des collections virtuelles" else "Create virtual collections",groups)}
        item{ActionCard("◷",if(fr)"Programmer un rappel" else "Schedule a reminder",if(fr)"Planifier une préparation ou une publication" else "Plan a preparation or post",calendar)}
        item{ActionCard("▤",if(fr)"Bibliothèque" else "Library",if(fr)"Retrouver et partager les brouillons" else "Find and share drafts",library)}
        item{Card(colors=CardDefaults.cardColors(containerColor=Navy),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(16.dp)){Text(if(fr)"Statut honnête" else "Honest status",color=Teal,fontWeight=FontWeight.Bold);Spacer(Modifier.height(6.dp));Text(if(fr)"Nexlink enregistre votre préparation. Le partage ouvre une application compatible ; l'envoi et la livraison doivent être vérifiés dans WhatsApp." else "Nexlink saves your preparation. Sharing opens a compatible app; sending and delivery must be checked in WhatsApp.",color=Color.White,fontSize=13.sp)}}}
    }
}
@Composable private fun StatCard(title:String,number:String,icon:androidx.compose.ui.graphics.vector.ImageVector,modifier:Modifier){Card(modifier,colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(11.dp)){Icon(icon,null,tint=Teal);Text(number,fontWeight=FontWeight.ExtraBold,fontSize=23.sp,color=MaterialTheme.colorScheme.onSurface);Text(title,color=Color.Gray,fontSize=11.sp)}}}
@Composable private fun ActionCard(symbol:String,title:String,subtitle:String,action:()->Unit){Card(Modifier.fillMaxWidth().clickable{action()},colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface),shape=RoundedCornerShape(16.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(42.dp).background(Teal.copy(alpha=.18f),CircleShape),contentAlignment=Alignment.Center){Text(symbol,color=Blue,fontSize=22.sp,fontWeight=FontWeight.Bold)};Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(title,color=MaterialTheme.colorScheme.onSurface,fontWeight=FontWeight.Bold);Text(subtitle,color=Color.Gray,fontSize=12.sp)};Icon(Icons.Default.ChevronRight,null,tint=Blue)}}}

@Composable private fun GroupsScreen(fr:Boolean,groups:List<VirtualGroup>,add:()->Unit,edit:(VirtualGroup)->Unit,delete:(String)->Unit){Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(vertical=10.dp)){Column(Modifier.weight(1f)){Text(if(fr)"Groupes virtuels" else "Virtual groups",fontSize=23.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground);Text(if(fr)"Collections organisées par vous" else "Collections organized by you",fontSize=12.sp,color=Color.Gray)};Button(onClick=add){Icon(Icons.Default.Add,null);Text(if(fr)"Ajouter" else "Add")}};if(groups.isEmpty())EmptyState(if(fr)"Aucun groupe virtuel" else "No virtual groups yet");LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(groups){g->Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.fillMaxWidth().padding(14.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.FolderSpecial,null,tint=Teal,modifier=Modifier.size(29.dp));Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(g.name,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface);Text(g.description.ifBlank{if(fr)"Collection Nexlink — les groupes WhatsApp ne sont pas importés automatiquement" else "Nexlink collection — WhatsApp groups are not imported automatically"},fontSize=11.sp,color=Color.Gray)};IconButton(onClick={edit(g)}){Icon(Icons.Default.Edit,null)};IconButton(onClick={delete(g.id)}){Icon(Icons.Default.DeleteOutline,null,tint=Color(0xFFB54545))}}}}}}
}
@Composable private fun GroupDialog(fr:Boolean,old:VirtualGroup?,dismiss:()->Unit,save:(String,String)->Unit){var name by remember(old?.id){mutableStateOf(old?.name?:"")};var desc by remember(old?.id){mutableStateOf(old?.description?:"")};AlertDialog(onDismissRequest=dismiss,title={Text(if(fr)"Groupe virtuel" else "Virtual group")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text(if(fr)"Nom de la collection" else "Collection name")},singleLine=true);OutlinedTextField(desc,{desc=it},label={Text(if(fr)"Description (facultatif)" else "Description (optional)")},minLines=2)}},confirmButton={TextButton(enabled=name.isNotBlank(),onClick={save(name.trim(),desc.trim())}){Text(if(fr)"Enregistrer" else "Save")}},dismissButton={TextButton(onClick=dismiss){Text(if(fr)"Annuler" else "Cancel")}})}

@Composable private fun LibraryScreen(fr:Boolean,drafts:List<Draft>,create:()->Unit,edit:(Draft)->Unit,share:(Draft)->Unit,delete:(Draft)->Unit,attach:()->Unit){Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(vertical=10.dp)){Text(if(fr)"Bibliothèque" else "Library",fontSize=24.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground,modifier=Modifier.weight(1f));Button(onClick=create){Icon(Icons.Default.Add,null);Text(if(fr)"Créer" else "Create")}};Text(if(fr)"Brouillons, médias joints et préparation par espace" else "Drafts, attached media and workspace preparation",color=Color.Gray,fontSize=12.sp);OutlinedButton(onClick=attach,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Text(if(fr)"Choisir un média à partager" else "Choose media to share")};Spacer(Modifier.height(8.dp));if(drafts.isEmpty())EmptyState(if(fr)"Aucun brouillon pour le moment" else "No drafts yet") else LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(drafts){d->Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Column(Modifier.padding(13.dp)){Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(d.title.ifBlank{if(fr)"Sans titre" else "Untitled"},fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface);Text("${d.workspace} · ${d.group.ifBlank{if(fr)"Sans groupe" else "No group"}}",fontSize=11.sp,color=Color.Gray);if(d.scheduleDate.isNotBlank()&&d.scheduleTime.isNotBlank())Text("${d.scheduleDate} · ${d.scheduleTime}",fontSize=11.sp,color=Teal)};Text(d.status,fontSize=10.sp,color=Teal)};Spacer(Modifier.height(6.dp));Text(d.body,color=MaterialTheme.colorScheme.onSurface,maxLines=5);if(d.attachment.isNotBlank()){Spacer(Modifier.height(4.dp));Text(if(fr)"Média joint" else "Media attached",fontSize=11.sp,color=Teal)};Row(horizontalArrangement=Arrangement.spacedBy(4.dp)){TextButton(onClick={edit(d)}){Icon(Icons.Default.Edit,null);Text(if(fr)"Modifier" else "Edit")};TextButton(onClick={share(d)}){Icon(Icons.Default.Share,null);Text(if(fr)"Partager" else "Share")};TextButton(onClick={delete(d)}){Icon(Icons.Default.DeleteOutline,null);Text(if(fr)"Supprimer" else "Delete")}}}}}}}
}
@Composable private fun DraftDialog(fr:Boolean,old:Draft?,workspace:String,groups:List<VirtualGroup>,attachment:String,chooseAttachment:()->Unit,onRecord:()->Unit,recording:Boolean,dismiss:()->Unit,save:(Draft)->Unit){var title by remember(old?.id){mutableStateOf(old?.title?:"")};var body by remember(old?.id){mutableStateOf(old?.body?:"")};var selectedGroup by remember(old?.id){mutableStateOf(old?.group?:"")};var selectedWorkspace by remember(old?.id){mutableStateOf(old?.workspace?:workspace)};var scheduleDate by remember(old?.id){mutableStateOf(old?.scheduleDate?:"")};var scheduleTime by remember(old?.id){mutableStateOf(old?.scheduleTime?:"")};AlertDialog(onDismissRequest=dismiss,title={Text(if(fr)"Préparer un message" else "Prepare a message")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text(if(fr)"Le brouillon est conservé localement. Le partage ne confirme pas l'envoi." else "Drafts are stored locally. Sharing does not confirm sending.",fontSize=11.sp,color=Color.Gray);OutlinedTextField(title,{title=it},label={Text(if(fr)"Titre" else "Title")},singleLine=true);Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(selected=selectedWorkspace=="Messenger",onClick={selectedWorkspace="Messenger"},label={Text("Messenger")});FilterChip(selected=selectedWorkspace=="Business",onClick={selectedWorkspace="Business"},label={Text("Business")})};var groupMenu by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={groupMenu=true},modifier=Modifier.fillMaxWidth()){Text(selectedGroup.ifBlank{if(fr)"Choisir un groupe virtuel" else "Choose virtual group"})};DropdownMenu(expanded=groupMenu,onDismissRequest={groupMenu=false}){DropdownMenuItem(text={Text(if(fr)"Aucun groupe" else "No group")},onClick={selectedGroup="";groupMenu=false});groups.forEach{g->DropdownMenuItem(text={Text(g.name)},onClick={selectedGroup=g.name;groupMenu=false})}}};OutlinedTextField(body,{body=it},label={Text(if(fr)"Message" else "Message")},minLines=4,maxLines=7);Text(if(fr)"Planification facultative" else "Optional scheduling",fontWeight=FontWeight.SemiBold,fontSize=12.sp);OutlinedTextField(scheduleDate,{scheduleDate=it},label={Text(if(fr)"Date (AAAA-MM-JJ)" else "Date (YYYY-MM-DD)")},singleLine=true);OutlinedTextField(scheduleTime,{scheduleTime=it},label={Text(if(fr)"Heure (HH:MM)" else "Time (HH:MM)")},singleLine=true);OutlinedButton(onClick=chooseAttachment,modifier=Modifier.fillMaxWidth()){Icon(Icons.Default.AttachFile,null);Spacer(Modifier.width(6.dp));Text(if(attachment.isNotBlank())if(fr)"Média sélectionné" else "Media selected" else if(fr)"Joindre image / vidéo / audio / PDF" else "Attach image / video / audio / PDF")};OutlinedButton(onClick=onRecord,modifier=Modifier.fillMaxWidth()){Icon(if(recording)Icons.Default.Stop else Icons.Default.Mic,null);Spacer(Modifier.width(6.dp));Text(if(recording)if(fr)"Arrêter l’enregistrement" else "Stop recording" else if(fr)"Enregistrer un audio" else "Record audio")}}},confirmButton={TextButton(enabled=body.isNotBlank()||attachment.isNotBlank(),onClick={save(Draft(old?.id?:java.util.UUID.randomUUID().toString(),title.trim(),body.trim(),selectedWorkspace,selectedGroup,attachment,old?.created?:System.currentTimeMillis(),if(scheduleDate.isNotBlank()&&scheduleTime.isNotBlank())"Planifié" else old?.status?:"Préparé",scheduleDate.trim(),scheduleTime.trim()))}){Text(if(fr)"Enregistrer" else "Save draft")}},dismissButton={TextButton(onClick=dismiss){Text(if(fr)"Fermer" else "Close")}})}

@Composable private fun CalendarScreen(fr:Boolean,reminders:List<Reminder>,drafts:List<Draft>,add:()->Unit,toggle:(Reminder)->Unit,delete:(String)->Unit){Column(Modifier.fillMaxSize().padding(horizontal=16.dp)){Row(verticalAlignment=Alignment.CenterVertically,modifier=Modifier.padding(vertical=10.dp)){Column(Modifier.weight(1f)){Text(if(fr)"Calendrier & rappels" else "Calendar & reminders",fontSize=22.sp,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground);Text(if(fr)"Rappels locaux sur cet appareil" else "Local reminders on this device",fontSize=12.sp,color=Color.Gray)};Button(onClick=add){Icon(Icons.Default.Add,null);Text(if(fr)"Rappel" else "Reminder")}};if(reminders.isEmpty()&&drafts.isEmpty())EmptyState(if(fr)"Aucun élément planifié" else "Nothing scheduled yet");LazyColumn(verticalArrangement=Arrangement.spacedBy(9.dp)){items(reminders){r->Card(colors=CardDefaults.cardColors(containerColor=MaterialTheme.colorScheme.surface)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Checkbox(checked=r.done,onCheckedChange={toggle(r)});Column(Modifier.weight(1f)){Text(r.title,fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onSurface);Text("${r.date} · ${r.time}",fontSize=12.sp,color=Teal);if(r.note.isNotBlank())Text(r.note,fontSize=12.sp,color=Color.Gray)};IconButton(onClick={delete(r.id)}){Icon(Icons.Default.DeleteOutline,null)}}}};if(drafts.isNotEmpty())item{Text(if(fr)"Publications préparées / planifiées" else "Prepared / scheduled posts",fontWeight=FontWeight.Bold,color=MaterialTheme.colorScheme.onBackground,modifier=Modifier.padding(top=10.dp))};items(drafts.take(10)){d->ListItem(headlineContent={Text(d.title.ifBlank{if(fr)"Brouillon sans titre" else "Untitled draft"})},supportingContent={Text(if(d.scheduleDate.isNotBlank()&&d.scheduleTime.isNotBlank())"${d.scheduleDate} · ${d.scheduleTime} · ${d.status}" else if(fr)"Prêt à partager · aucune publication automatique" else "Ready to share · no automatic publishing")},leadingContent={Icon(Icons.Default.EditNote,null,tint=Teal)})}}}
}
@Composable private fun ReminderDialog(fr:Boolean,dismiss:()->Unit,save:(Reminder)->Unit){var title by remember{mutableStateOf("")};var date by remember{mutableStateOf(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date(System.currentTimeMillis()+3600000)))};var time by remember{mutableStateOf(SimpleDateFormat("HH:mm",Locale.US).format(Date(System.currentTimeMillis()+3600000)))};var note by remember{mutableStateOf("")};AlertDialog(onDismissRequest=dismiss,title={Text(if(fr)"Nouveau rappel" else "New reminder")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){OutlinedTextField(title,{title=it},label={Text(if(fr)"Activité / motif" else "Activity / reason")},singleLine=true);OutlinedTextField(date,{date=it},label={Text(if(fr)"Date (AAAA-MM-JJ)" else "Date (YYYY-MM-DD)")},singleLine=true);OutlinedTextField(time,{time=it},label={Text(if(fr)"Heure (HH:MM)" else "Time (HH:MM)")},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Ascii));OutlinedTextField(note,{note=it},label={Text(if(fr)"Notes" else "Notes")},minLines=2);Text(if(fr)"Autorisez les notifications Android pour recevoir les alertes. Les rappels restent visibles ici." else "Allow Android notifications to receive alerts. Reminders remain visible here.",fontSize=11.sp,color=Color.Gray)}},confirmButton={TextButton(enabled=title.isNotBlank()&&validDateTime(date,time),onClick={save(Reminder(java.util.UUID.randomUUID().toString(),title.trim(),date,time,note.trim()))}){Text(if(fr)"Programmer" else "Schedule")}},dismissButton={TextButton(onClick=dismiss){Text(if(fr)"Annuler" else "Cancel")}})}
private fun validDateTime(d:String,t:String):Boolean=try{SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).apply{isLenient=false}.parse("$d $t")!=null}catch(_:Exception){false}
private fun scheduleReminder(context:Context,r:Reminder){try{val sdf=SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US);val at=sdf.parse("${r.date} ${r.time}")?.time?:return;val delay=at-System.currentTimeMillis();if(delay<=0)return;val data=workDataOf("title" to r.title,"note" to r.note,"id" to r.id);val req=OneTimeWorkRequestBuilder<ReminderWorker>().setInitialDelay(delay,TimeUnit.MILLISECONDS).setInputData(data).addTag("nexlink_reminder").build();WorkManager.getInstance(context).enqueueUniqueWork("reminder_${r.id}",ExistingWorkPolicy.REPLACE,req)}catch(_:Exception){}}
class ReminderWorker(ctx:Context,params:WorkerParameters):Worker(ctx,params){override fun doWork():Result{val title=inputData.getString("title")?:"Nexlink reminder";val note=inputData.getString("note")?:"";val id=inputData.getString("id")?.hashCode()?:System.currentTimeMillis().toInt();if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){val nm=applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager;nm.createNotificationChannel(NotificationChannel(CHANNEL_ID,"Nexlink reminders",NotificationManager.IMPORTANCE_HIGH))};val n=NotificationCompat.Builder(applicationContext,CHANNEL_ID).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(note.ifBlank{"Reminder from Nexlink"}).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).build();try{if(Build.VERSION.SDK_INT<33||ContextCompat.checkSelfPermission(applicationContext,Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)NotificationManagerCompat.from(applicationContext).notify(id,n)}catch(_:SecurityException){};return Result.success()}}

@Composable
private fun SettingsScreen(
    fr: Boolean, workspace: String, setWorkspace: (String) -> Unit,
    language: String, setLanguage: (String) -> Unit,
    dark: Boolean, setDark: (Boolean) -> Unit,
    profiles: List<PubProfile>, addProfile: () -> Unit,
    deleteProfile: (PubProfile) -> Unit, export: () -> Unit,
    import: () -> Unit, notifications: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(if (fr) "Réglages" else "Settings", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(Modifier.height(10.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(if (fr) "Apparence" else "Appearance", fontWeight = FontWeight.Bold)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (fr) "Thème sombre" else "Dark theme", modifier = Modifier.weight(1f))
                            Switch(checked = dark, onCheckedChange = setDark)
                        }
                        Text(if (fr) "Langue" else "Language", fontWeight = FontWeight.Bold)
                        Row {
                            FilterChip(selected = language == "FR", onClick = { setLanguage("FR") }, label = { Text("Français") })
                            Spacer(Modifier.width(8.dp))
                            FilterChip(selected = language == "EN", onClick = { setLanguage("EN") }, label = { Text("English") })
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(if (fr) "Espaces de travail" else "Workspaces", fontWeight = FontWeight.Bold)
                        Row {
                            FilterChip(selected = workspace == "Messenger", onClick = { setWorkspace("Messenger") }, label = { Text("Messenger") })
                            Spacer(Modifier.width(6.dp))
                            FilterChip(selected = workspace == "Business", onClick = { setWorkspace("Business") }, label = { Text("Business") })
                        }
                        Text(if (fr) "Ce sélecteur organise vos contenus Nexlink. Il ne détecte pas automatiquement le compte WhatsApp actif." else "This selector organizes Nexlink content. It does not automatically detect the active WhatsApp account.", fontSize = 11.sp, color = Color.Gray)
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(15.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (fr) "Profils de publication" else "Publication profiles", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            IconButton(onClick = addProfile) { Icon(Icons.Default.Add, null) }
                        }
                        if (profiles.isEmpty()) Text(if (fr) "Créez des profils pour distinguer vos usages." else "Create profiles for different publishing workflows.", fontSize = 12.sp, color = Color.Gray)
                        profiles.forEach { p ->
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(p.name, fontWeight = FontWeight.SemiBold)
                                    Text("${p.workspace} · ${p.description}", fontSize = 11.sp, color = Color.Gray)
                                }
                                IconButton(onClick = { deleteProfile(p) }) { Icon(Icons.Default.DeleteOutline, null) }
                            }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(if (fr) "Sauvegarde et restauration" else "Backup and restore", fontWeight = FontWeight.Bold)
                        Text(if (fr) "Exporte les groupes, brouillons, rappels et profils Nexlink uniquement. Les conversations WhatsApp ne sont pas incluses." else "Exports Nexlink groups, drafts, reminders and profiles only. WhatsApp conversations are not included.", fontSize = 12.sp, color = Color.Gray)
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedButton(onClick = export) { Icon(Icons.Default.FileUpload, null); Text(if (fr) "Exporter" else "Export") }
                            OutlinedButton(onClick = import) { Icon(Icons.Default.FileDownload, null); Text(if (fr) "Restaurer" else "Restore") }
                        }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(if (fr) "Notifications" else "Notifications", fontWeight = FontWeight.Bold)
                        Text(if (fr) "Autorisez les notifications pour recevoir les rappels locaux." else "Allow notifications to receive local reminders.", fontSize = 12.sp, color = Color.Gray)
                        OutlinedButton(onClick = notifications) { Icon(Icons.Default.Notifications, null); Text(if (fr) "Configurer les notifications" else "Configure notifications") }
                    }
                }
            }
            item {
                Card(colors = CardDefaults.cardColors(containerColor = Navy)) {
                    Column(Modifier.padding(15.dp)) {
                        Text(if (fr) "Limites et confidentialité" else "Limits and privacy", fontWeight = FontWeight.Bold, color = Teal)
                        Text(if (fr) "Nexlink ne lit pas la base privée WhatsApp, ne découvre pas universellement les groupes et ne confirme pas les livraisons. Le partage ouvre les applications compatibles." else "Nexlink does not read WhatsApp's private database, universally discover groups, or confirm delivery. Sharing opens compatible apps.", fontSize = 12.sp, color = Color.White)
                    }
                }
            }
        }
    }
}
@Composable private fun ProfileDialog(fr:Boolean,dismiss:()->Unit,save:(String,String)->Unit){var name by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};AlertDialog(onDismissRequest=dismiss,title={Text(if(fr)"Nouveau profil" else "New profile")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){OutlinedTextField(name,{name=it},label={Text(if(fr)"Nom du profil" else "Profile name")},singleLine=true);OutlinedTextField(desc,{desc=it},label={Text(if(fr)"Description" else "Description")},minLines=2)}},confirmButton={TextButton(enabled=name.isNotBlank(),onClick={save(name.trim(),desc.trim())}){Text(if(fr)"Créer" else "Create")}},dismissButton={TextButton(onClick=dismiss){Text(if(fr)"Annuler" else "Cancel")}})}
private fun shareDraft(context:Context,d:Draft){val uri=if(d.attachment.isNotBlank())try{Uri.parse(d.attachment)}catch(_:Exception){null}else null;val mime=if(uri!=null)context.contentResolver.getType(uri)?:"application/octet-stream" else "text/plain";val intent=Intent(Intent.ACTION_SEND).apply{type=mime;putExtra(Intent.EXTRA_SUBJECT,d.title);putExtra(Intent.EXTRA_TEXT,listOf(d.title,d.body).filter{it.isNotBlank()}.joinToString("\n\n"));if(uri!=null){putExtra(Intent.EXTRA_STREAM,uri);addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)}};context.startActivity(Intent.createChooser(intent,"Nexlink · Share via"))}
@Composable private fun EmptyState(text:String){Box(Modifier.fillMaxWidth().padding(vertical=32.dp),contentAlignment=Alignment.Center){Column(horizontalAlignment=Alignment.CenterHorizontally){Icon(Icons.Default.Inbox,null,tint=Teal,modifier=Modifier.size(42.dp));Spacer(Modifier.height(8.dp));Text(text,color=Color.Gray)}}}
