# Nexlink — Android source project (0.2.0)

Nexlink is a local-first Android companion for organizing content and preparing messages for WhatsApp Messenger and WhatsApp Business. Brand direction: deep navy and turquoise.

## Implemented in this source
- French / English interface toggle and light/dark theme.
- Separate Messenger and Business content workspaces (organizational labels; not automatic WhatsApp account detection).
- Local persistent virtual groups/collections, with starter collections for Record Breaking Prayers, Breaking The Chains and Les Grandes Bouches.
- Persistent message drafts with title, content, workspace, group, optional planned date/time, and attachment reference.
- Media selection through Android's document picker; local audio recording through the microphone permission and Android MediaRecorder.
- Android share sheet for drafts and attachments. The app reports only that sharing was initiated; it cannot verify WhatsApp send/delivery.
- Calendar list of local reminders and planned drafts. WorkManager schedules local notifications for future reminders and scheduled drafts.
- Publication profiles.
- Search within Nexlink groups and drafts.
- JSON export/import of Nexlink metadata (not WhatsApp conversations or private databases).
- Explicit privacy and integration limitations.

## Important limitations
- This source project has not been compiled or tested in this environment. An installable APK is not included.
- Scheduled dates/times use `YYYY-MM-DD` and `HH:mm` text fields. Android battery/notification settings can affect delivery of local notifications.
- Attachments are shared using Android intents. Available destination apps and their handling of attachments vary by device and app version.
- Nexlink does not scrape private WhatsApp data, enumerate arbitrary WhatsApp groups, read online status/deleted messages, or automate/confirm sending without official support.
- Backups contain Nexlink-created metadata only. Media file bytes are not bundled in the JSON backup.

## Build in Android Studio
1. Open the `Nexlink` folder in a recent Android Studio version.
2. Allow Gradle sync (internet is required to download Android Gradle Plugin and dependencies).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. Install the generated debug APK on your Android device and test microphone, file sharing and notifications.

Android build prerequisites: JDK 17, Android SDK Platform 35, Android Gradle Plugin 8.7.3 / Gradle 8.9 or compatible.

## Automated build on GitHub

The repository includes `.github/workflows/android-build.yml`. After this source project is pushed to a GitHub repository with Actions enabled, the workflow runs Android lint and unit-test tasks, builds a debug APK, and uploads `Nexlink-debug-apk` as a workflow artifact if the build succeeds. This is not a prebuilt APK; the workflow must run successfully first. The artifact is temporary (14-day retention) and is unsigned for Play Store release.
